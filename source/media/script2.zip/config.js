/* JANGAN DIHAPUS SAYANG, AMBILIN AJA CASE NYA
THANKS TO
- CyberX And Kryx
- all creator bot whatsapp

free for all : -_-
jangan pernah memperjual belikan script ini
dijual? neraka paling bawah
"Janganlah engkau menjual sesuatu yang bukan milikmu," (HR. Abu Dawud).

*/
module.exports = {
PTERODACTYL_URL: "https://rizxvelz.tokomurah.myserver-panel.me", // wajib isi
PTERODACTYL_TOKEN: "ptla_0qweW5IjpxANXFqZ5Klv1DX3f5LcoIOv3J7cEz2rSQZ", // wajib isi
SKIP_ADMIN_USERS: true, // true/false
SKIP_SERVERS_IDS: [], // bebas isi/engga
SKIP_USERS: [], // bebas isi/engga
FETCH_LIMIT: [5] // wajib isi
};
