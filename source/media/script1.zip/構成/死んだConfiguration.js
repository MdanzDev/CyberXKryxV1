module.exports = {
  tokenBot: "7305565903:AAFk1NarBlhSwMvCGT9gC6uLooFjo6AMh2E",
  ownerID: "7160254808",
};